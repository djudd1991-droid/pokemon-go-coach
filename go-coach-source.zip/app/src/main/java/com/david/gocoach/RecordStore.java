package com.david.gocoach;
import android.content.Context;
import org.json.*;
import java.util.*;

final class RecordStore {
 final android.content.SharedPreferences prefs;
 RecordStore(Context c){prefs=c.getSharedPreferences("data",0);}
 JSONArray all(){try{return new JSONArray(prefs.getString("collection","[]"));}catch(Exception e){return new JSONArray();}}
 JSONObject get(String id){JSONArray a=all();for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null&&o.optString("id").equals(id))return o;}return null;}
 List<JSONObject> matches(String fp){List<JSONObject> out=new ArrayList<>();if(fp.isEmpty())return out;JSONArray a=all();for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null&&o.optString("fingerprint").equals(fp))out.add(o);}return out;}
 static JSONObject encode(Reading r){JSONObject o=new JSONObject();try{o.put("species",r.species);o.put("cp",r.cp);o.put("maximum",r.maximum);o.put("weight",r.weight);o.put("height",r.height);o.put("fast",r.fast);o.put("charged",new JSONArray(r.charged));if(r.iv!=null)o.put("iv",new JSONArray(Arrays.asList(r.iv[0],r.iv[1],r.iv[2])));}catch(Exception ignored){}return o;}
 static boolean conflict(Reading r,JSONObject record){JSONObject d=record.optJSONObject("details");JSONArray iv=d==null?null:d.optJSONArray("iv");return r.iv!=null&&iv!=null&&iv.length()==3&&(r.iv[0]!=iv.optInt(0)||r.iv[1]!=iv.optInt(1)||r.iv[2]!=iv.optInt(2));}
 static void recall(Reading r,JSONObject record){
  JSONObject d=record.optJSONObject("details");
  if(d==null){d=new JSONObject();java.util.regex.Matcher m=java.util.regex.Pattern.compile("Appraisal: ([0-9]{1,2})\\s*/\\s*([0-9]{1,2})\\s*/\\s*([0-9]{1,2})").matcher(record.optString("stats"));if(m.find())try{JSONArray a=new JSONArray();for(int i=1;i<=3;i++){int v=Integer.parseInt(m.group(i));if(v>15)return;a.put(v);}d.put("iv",a);}catch(Exception ignored){}}
  JSONArray iv=d.optJSONArray("iv");if(r.iv==null&&iv!=null&&iv.length()==3){r.iv=new int[]{iv.optInt(0),iv.optInt(1),iv.optInt(2)};r.savedIv=true;}
  String fast=d.optString("fast");if(r.fast.isEmpty()&&!fast.isEmpty()){r.fast=fast;r.savedMoves=true;}
  JSONArray charged=d.optJSONArray("charged");if(charged!=null){if(r.charged.isEmpty()){for(int i=0;i<charged.length();i++)r.charged.add(charged.optString(i));r.savedMoves|=charged.length()>0;}else if(r.charged.size()==1&&charged.length()==2&&!r.charged.get(0).equals(charged.optString(1))){r.charged.add(charged.optString(1));r.savedMoves=true;}}
 }
 boolean update(String id,Reading r,boolean explicit){JSONArray a=all();for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null||!o.optString("id").equals(id))continue;if(!explicit&&conflict(r,o))return false;try{recall(r,o);JSONObject old=o.optJSONObject("details");if(old!=null&&old.toString().equals(encode(r).toString())&&o.optString("fingerprint").equals(r.fingerprint()))return true;if(old!=null&&!old.toString().equals(encode(r).toString()))o.put("previousDetails",old);o.put("details",encode(r));o.put("fingerprint",r.fingerprint());o.put("stats",r.summary());o.put("time",System.currentTimeMillis());return prefs.edit().putString("collection",a.toString()).commit();}catch(Exception e){return false;}}return false;}
}
