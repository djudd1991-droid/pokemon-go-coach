package com.david.gocoach;

import android.app.*;
import android.os.*;
import android.content.*;
import android.net.Uri;
import android.provider.Settings;
import android.media.projection.MediaProjectionManager;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import org.json.*;

public class MainActivity extends Activity {
 LinearLayout body; JSONObject pendingScan;
 protected void onCreate(Bundle b) { super.onCreate(b); home(); }
 TextView text(String s,int size) { TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(Color.WHITE); t.setPadding(0,14,0,14); body.addView(t); return t; }
 void button(String s,Runnable r) { Button b=new Button(this); b.setText(s); b.setAllCaps(false); b.setTextSize(16); b.setTextColor(Color.WHITE); android.graphics.drawable.GradientDrawable shape=new android.graphics.drawable.GradientDrawable(); shape.setColor(Color.rgb(30,70,73)); shape.setCornerRadius(22); b.setBackground(shape); LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1, (int)(54*getResources().getDisplayMetrics().density)); bp.setMargins(0,10,0,10); body.addView(b,bp); b.setOnClickListener(v->r.run()); }
 void page(String title) {
  ScrollView scroll=new ScrollView(this); body=new LinearLayout(this); body.setOrientation(1); body.setPadding(24,24,24,24); body.setBackgroundColor(Color.rgb(18,25,38)); scroll.setFillViewport(true); scroll.setBackgroundColor(Color.rgb(18,25,38)); scroll.addView(body); setContentView(scroll);
  scroll.setOnApplyWindowInsetsListener((v,i)->{android.graphics.Insets x=i.getInsets(WindowInsets.Type.systemBars()); v.setPadding(x.left,x.top,x.right,x.bottom); return i;}); text(title,28);
 }
 void home() {
  page("GO Coach · 0.4");
  text("Collection memory + moves • On-device",16);
  text("Open details or Appraise and hold still for two scans. To recall an older record, tap GO → Link saved Pokémon once. Show the moves section to record its visible attacks. Saved values are labeled.",17);
  button("1 · Allow floating coach",()->startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName()))));
  button("2 · Start screen reader",()->{
   if(!Settings.canDrawOverlays(this)){new AlertDialog.Builder(this).setMessage("Allow the floating coach first, then return here.").setPositiveButton("OK",null).show();return;}
   stopService(new Intent(this,CoachService.class));
   if(Build.VERSION.SDK_INT>=33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=0)requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},20);
   startActivityForResult(((MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE)).createScreenCaptureIntent(),10);
  });
  button("Stop reader",()->stopService(new Intent(this,CoachService.class)));
  button("Review saved scans",this::scans);
  button("My collection",this::collection);
  text("Image matches are tentative. Armored Mewtwo may remain unknown; Glimmet is not supported by this matcher. Wild-map and raid detection, shiny/background verification, inventory, and automatic collection syncing are not ready. Review each saved record.",15);
 }
 protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);if(req==10&&result==RESULT_OK&&data!=null){Intent i=new Intent(this,CoachService.class); i.putExtra("consent",data);startForegroundService(i);}}
 JSONArray read(String key){try{return new JSONArray(getSharedPreferences("data",0).getString(key,"[]"));}catch(Exception e){return new JSONArray();}}
 void save(String key,JSONArray a){getSharedPreferences("data",0).edit().putString(key,a.toString()).apply();}
 void scans(){page("Saved scans");button("Back",this::home);JSONArray a=read("scans");text("These are unverified text readings, not identified Pokémon. Tap a scan to review it and create a separate collection record.",15);for(int n=a.length()-1;n>=0;n--){JSONObject o=a.optJSONObject(n);if(o==null)continue;String raw=o.optString("text");button(new java.util.Date(o.optLong("time"))+"\n"+raw.substring(0,Math.min(75,raw.length())),()->new AlertDialog.Builder(this).setTitle("Unverified scan").setMessage(raw).setPositiveButton("Add Pokémon",(d,w)->{pendingScan=o;editRecord(raw);}).setNegativeButton("Close",null).show());}if(a.length()==0)text("No scans saved. Use Save in the floating coach after opening a game screen.",17);}
 void editRecord(String raw){
  page("Confirm Pokémon");text("Give each duplicate its own record. Review the extracted appraisal values. Collectible traits remain unknown until you confirm them.",15);
  EditText name=new EditText(this);name.setHint("Pokémon / nickname (required)");body.addView(name);
  EditText stats=new EditText(this);int cut=raw.indexOf("Raw OCR (unverified):");if(cut>0)stats.setText(raw.substring(0,cut).trim());stats.setHint("CP · Attack/Defense/HP · moves (optional)");body.addView(stats);
  CheckBox protect=new CheckBox(this);protect.setText("Protect from transfer suggestions");protect.setChecked(true);body.addView(protect);
  EditText traits=new EditText(this);traits.setHint("Shiny / background / form — leave blank if unknown");body.addView(traits);
  button("Save new Pokémon",()->{if(name.getText().toString().trim().isEmpty()){name.setError("Enter a name");return;}try{JSONArray a=read("collection");JSONObject o=new JSONObject();o.put("id",java.util.UUID.randomUUID().toString());o.put("name",name.getText().toString());o.put("stats",stats.getText().toString());o.put("traits",traits.getText().toString());o.put("protected",protect.isChecked());o.put("scan",raw);if(pendingScan!=null&&pendingScan.optJSONObject("details")!=null&&cut>0&&stats.getText().toString().equals(raw.substring(0,cut).trim())){o.put("details",pendingScan.optJSONObject("details"));o.put("fingerprint",pendingScan.optString("fingerprint"));}o.put("time",System.currentTimeMillis());a.put(o);save("collection",a);collection();}catch(Exception e){text("Could not save record.",16);}});button("Cancel",this::scans);
 }
 void collection(){page("My collection");button("Back",this::home);button("Add a Pokémon manually",()->{pendingScan=null;editRecord("");});JSONArray a=read("collection");if(a.length()==0)text("No confirmed Pokémon yet.",17);for(int n=0;n<a.length();n++){final int index=n;JSONObject o=a.optJSONObject(n);if(o==null)continue;button(o.optString("name")+" · "+(o.optBoolean("protected")?"Protected":"Review before transfer"),()->new AlertDialog.Builder(this).setTitle(o.optString("name")).setMessage(o.optString("stats")+"\nTraits: "+(o.optString("traits").isEmpty()?"Unknown":o.optString("traits"))+"\n\nSaved: "+new java.util.Date(o.optLong("time"))).setPositiveButton("Close",null).setNeutralButton("Remove record",(d,w)->new AlertDialog.Builder(this).setMessage("Remove this saved record? This does not transfer anything in Pokémon GO.").setPositiveButton("Remove",(dd,ww)->{a.remove(index);save("collection",a);collection();}).setNegativeButton("Cancel",null).show()).show());}}
}
