package com.david.gocoach;

import android.content.Context;
import android.graphics.Bitmap;
import org.json.*;
import org.opencv.android.*;
import org.opencv.core.*;
import org.opencv.features2d.*;
import org.opencv.calib3d.Calib3d;
import org.opencv.imgproc.Imgproc;
import java.util.*;

/** Experimental reference matching for a single details-screen Pokemon; no text is used as identity evidence. */
public final class VisualMatcher implements AutoCloseable {
 static final class Reference {String species;Point[] points;Mat descriptors;}
 final List<Reference> references=new ArrayList<>();
 SIFT sift;BFMatcher matcher;
 public VisualMatcher(Context context)throws Exception {
  if(!OpenCVLoader.initLocal())throw new IllegalStateException("OpenCV could not load");
  Core.setNumThreads(1);
  sift=SIFT.create(2000,3,0.015,10,1.6);matcher=BFMatcher.create(Core.NORM_L2,false);
  try(java.io.InputStream in=context.getAssets().open("visual-references.json")){
   java.io.ByteArrayOutputStream bytes=new java.io.ByteArrayOutputStream();byte[] chunk=new byte[8192];int n;while((n=in.read(chunk))!=-1)bytes.write(chunk,0,n);
   JSONArray all=new JSONArray(bytes.toString("UTF-8"));
   for(int i=0;i<all.length();i++){
    JSONObject o=all.getJSONObject(i);Reference ref=new Reference();ref.species=o.getString("species");JSONArray points=o.getJSONArray("points"),desc=o.getJSONArray("descriptors");
    ref.points=new Point[points.length()];float[] values=new float[points.length()*128];
    for(int j=0;j<points.length();j++){JSONArray pt=points.getJSONArray(j);ref.points[j]=new Point(pt.getDouble(0),pt.getDouble(1));JSONArray row=desc.getJSONArray(j);for(int k=0;k<128;k++)values[j*128+k]=(float)row.getDouble(k);}
    ref.descriptors=new Mat(points.length(),128,CvType.CV_32F);ref.descriptors.put(0,0,values);references.add(ref);
   }
  }
 }
 public String identify(Bitmap bitmap){
  Mat rgba=new Mat(),gray=new Mat(),desc=new Mat(),empty=new Mat();MatOfKeyPoint keypoints=new MatOfKeyPoint();Mat roi=null;
  try{
   Utils.bitmapToMat(bitmap,rgba);int w=rgba.cols(),h=rgba.rows();
   roi=rgba.submat(new Rect((int)(w*.08),(int)(h*.10),(int)(w*.88)-(int)(w*.08),(int)(h*.345)-(int)(h*.10)));
   Imgproc.cvtColor(roi,gray,Imgproc.COLOR_RGBA2GRAY);sift.detectAndCompute(gray,empty,keypoints,desc);
   if(desc.rows()<2)return "";
   KeyPoint[] target=keypoints.toArray();Map<String,Integer> scores=new HashMap<>();Map<String,Double> coverage=new HashMap<>();
   for(Reference ref:references){
    List<MatOfDMatch> pairs=new ArrayList<>();Map<Integer,DMatch> unique=new HashMap<>();
    try{matcher.knnMatch(ref.descriptors,desc,pairs,2);for(MatOfDMatch pair:pairs){DMatch[] a=pair.toArray();if(a.length==2&&a[0].distance<.70*a[1].distance){DMatch old=unique.get(a[0].trainIdx);if(old==null||old.distance>a[0].distance)unique.put(a[0].trainIdx,a[0]);}}}finally{for(MatOfDMatch pair:pairs)pair.release();}
    if(unique.size()<4)continue;
    List<DMatch> matches=new ArrayList<>(unique.values());matches.sort(Comparator.comparingDouble(m->m.distance));
    Point[] from=new Point[matches.size()],to=new Point[matches.size()];
    for(int j=0;j<matches.size();j++){DMatch m=matches.get(j);from[j]=ref.points[m.queryIdx];to[j]=target[m.trainIdx].pt;}
    MatOfPoint2f a=new MatOfPoint2f(from),b=new MatOfPoint2f(to);Mat mask=new Mat(),H=null;MatOfPoint poly=null;MatOfInt hull=null;MatOfPoint outline=null;
    try{
     H=Calib3d.findHomography(a,b,Calib3d.RANSAC,4.0,mask);if(H.empty()||mask.empty())continue;
     List<Point> points=new ArrayList<>();for(int j=0;j<to.length;j++)if(mask.get(j,0)[0]!=0)points.add(to[j]);
     int count=points.size();double area=0;
     if(count>=3){poly=new MatOfPoint();poly.fromList(points);hull=new MatOfInt();Imgproc.convexHull(poly,hull);int[] indices=hull.toArray();Point[] hp=new Point[indices.length];for(int j=0;j<indices.length;j++)hp[j]=points.get(indices[j]);outline=new MatOfPoint(hp);area=Imgproc.contourArea(outline)/(gray.rows()*gray.cols());}
     if(count>scores.getOrDefault(ref.species,0)){scores.put(ref.species,count);coverage.put(ref.species,area);}
    }finally{a.release();b.release();mask.release();if(H!=null)H.release();if(poly!=null)poly.release();if(hull!=null)hull.release();if(outline!=null)outline.release();}
   }
   String best="";int high=0,second=0;
   for(Map.Entry<String,Integer> e:scores.entrySet()){if(e.getValue()>high){second=high;high=e.getValue();best=e.getKey();}else second=Math.max(second,e.getValue());}
   return high>=10&&high>=second+4&&coverage.getOrDefault(best,0.0)>=.015?best:"";
  }finally{if(roi!=null)roi.release();rgba.release();gray.release();desc.release();empty.release();keypoints.release();}
 }
 public void close(){for(Reference ref:references)ref.descriptors.release();references.clear();if(sift!=null)sift.clear();if(matcher!=null)matcher.clear();}
}
