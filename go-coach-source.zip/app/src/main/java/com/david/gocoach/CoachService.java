package com.david.gocoach;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.os.*;
import android.graphics.*;
import android.hardware.display.*;
import android.media.*;
import android.media.projection.*;
import android.view.*;
import android.widget.*;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.*;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import org.json.*;

public class CoachService extends Service {
 final java.util.concurrent.ExecutorService visionWorker=java.util.concurrent.Executors.newSingleThreadExecutor(); VisualMatcher visualMatcher; boolean visualUnavailable=false;
 RecordStore recordStore; Reading currentReading; String linkedId="", linkedKey=""; final java.util.Map<String,String> moveCatalog=new java.util.HashMap<>();
 final Handler handler=new Handler(Looper.getMainLooper());
 MediaProjection projection; VirtualDisplay display; ImageReader reader; WindowManager wm;
 LinearLayout panel,controls; TextView title; TextView message; TextRecognizer recognizer;
 WindowManager.LayoutParams params; boolean paused=false,busy=false,dead=false,small=false; long last=0;String latest="", previousSummary="", structured=""; int matches=0; boolean stable=false; int generation=0;
 public IBinder onBind(Intent i){return null;}
 public int onStartCommand(Intent intent,int flags,int id){
  if(intent==null || "STOP".equals(intent.getAction())){stopSelf();return START_NOT_STICKY;}
  if(projection!=null)return START_NOT_STICKY;
  NotificationManager nm=getSystemService(NotificationManager.class);nm.createNotificationChannel(new NotificationChannel("reader","Screen reader",NotificationManager.IMPORTANCE_LOW));
  PendingIntent stop=PendingIntent.getService(this,0,new Intent(this,CoachService.class).setAction("STOP"),PendingIntent.FLAG_IMMUTABLE);
  Notification n=new Notification.Builder(this,"reader").setSmallIcon(android.R.drawable.ic_menu_view).setContentTitle("GO Coach is reading your shared screen").setContentText("Tap Stop when finished").setOngoing(true).addAction(new Notification.Action.Builder(null,"Stop",stop).build()).build();
  startForeground(1,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
  try{
   Intent consent=intent.getParcelableExtra("consent");if(consent==null){stopSelf();return START_NOT_STICKY;}
   projection=((MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE)).getMediaProjection(Activity.RESULT_OK,consent);
   projection.registerCallback(new MediaProjection.Callback(){public void onStop(){stopSelf();}public void onCapturedContentResize(int width,int height){resize(width,height);}},handler);
   recordStore=new RecordStore(this);
   try{PvpGrade.load(getAssets().open("pvp.json"));}catch(Exception ignored){}
   try(java.io.BufferedReader lines=new java.io.BufferedReader(new java.io.InputStreamReader(getAssets().open("moves.tsv"),java.nio.charset.StandardCharsets.UTF_8))){String line;while((line=lines.readLine())!=null){String[] parts=line.split("\t",2);if(parts.length==2)moveCatalog.put(parts[1].replaceAll("[^A-Za-z]", "").toLowerCase(java.util.Locale.ROOT),line);}}
   recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
   wm=getSystemService(WindowManager.class);Rect bounds=wm.getMaximumWindowMetrics().getBounds();
   createReader(bounds.width(),bounds.height());
   display=projection.createVirtualDisplay("GO Coach",reader.getWidth(),reader.getHeight(),getResources().getDisplayMetrics().densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,handler);
   overlay();
  }catch(Exception e){Toast.makeText(this,"Reader could not start. Reopen GO Coach and approve sharing again.",Toast.LENGTH_LONG).show();stopSelf();}
  return START_NOT_STICKY;
 }
 void createReader(int w,int h){reader=ImageReader.newInstance(w,h,PixelFormat.RGBA_8888,2);reader.setOnImageAvailableListener(r->frame(r),handler);}
 void resize(int w,int h){if(dead||display==null||w<=0||h<=0||reader==null)return;if(reader.getWidth()==w&&reader.getHeight()==h)return;display.setSurface(null);reader.close();createReader(w,h);display.resize(w,h,getResources().getDisplayMetrics().densityDpi);display.setSurface(reader.getSurface());}
 void frame(ImageReader r){
  Image im=null;Bitmap bitmap=null;
  try{
   im=r.acquireLatestImage();if(im==null)return;
   long now=SystemClock.elapsedRealtime();if(dead||paused||busy||now-last<3000)return;
   last=now; Image.Plane p=im.getPlanes()[0];int w=im.getWidth(),h=im.getHeight();int padded=p.getRowStride()/p.getPixelStride();
   Bitmap full=Bitmap.createBitmap(padded,h,Bitmap.Config.ARGB_8888);full.copyPixelsFromBuffer(p.getBuffer());bitmap=Bitmap.createBitmap(full,0,0,w,h);if(bitmap!=full)full.recycle();
   if(w>1080){Bitmap reduced=Bitmap.createScaledBitmap(bitmap,1080,Math.max(1,h*1080/w),true);bitmap.recycle();bitmap=reduced;}
   busy=true;final Bitmap work=bitmap;bitmap=null;final int epoch=generation;
   recognizer.process(InputImage.fromBitmap(work,0)).addOnCompleteListener(task->{
    if(dead||paused||epoch!=generation||!task.isSuccessful()){
     if(!dead&&!task.isSuccessful())message.setText("Text reading failed. Hold the screen still.");
     finishFrame(work);return;
    }
    Text result=task.getResult();
    visionWorker.execute(()->{
     String match="";
     try{
      Reading prelim=Reading.parse(result.getText());
      // OCR selects the kind of screen only. Species matching sees only the upper image crop.
      if(!prelim.cp.equals("Unknown")&&prelim.current>=0){
       if(visualMatcher==null&&!visualUnavailable){try{visualMatcher=new VisualMatcher(this);}catch(Exception|LinkageError e){visualUnavailable=true;}}
       if(visualMatcher!=null)match=visualMatcher.identify(work);
      }
     }catch(Exception e){match="";}
     final String found=match;
     handler.post(()->{try{if(!dead&&!paused&&epoch==generation)accept(result,work,found);}finally{finishFrame(work);}});
    });
   });
  }catch(Exception e){if(message!=null)message.setText("Unable to read this frame. Try restarting sharing.");}
  finally{if(im!=null)im.close();if(bitmap!=null)bitmap.recycle();}
 }
 void finishFrame(Bitmap work){work.recycle();busy=false;if(dead&&recognizer!=null)recognizer.close();}
 void accept(Text t,Bitmap bitmap,String visual){
  latest=t.getText();Reading r=Reading.parse(latest);boolean fromImage=r.species.equals("Unknown")&&!visual.isEmpty();if(fromImage)r.species=visual;
  Reading.Anchor[] anchors=new Reading.Anchor[3];
  for(Text.TextBlock block:t.getTextBlocks())for(Text.Line line:block.getLines()){
   String label=line.getText().trim().toLowerCase(java.util.Locale.ROOT);Rect b=line.getBoundingBox();if(b==null)continue;
   int i=label.equals("attack")?0:label.equals("defense")?1:label.equals("hp")?2:-1;
   if(i>=0 && b.left<bitmap.getWidth()*.50 && b.top>bitmap.getHeight()*.45)anchors[i]=new Reading.Anchor(b.left,b.bottom);
  }
  r.iv=Reading.appraisal(new Reading.Pixels(){public int width(){return bitmap.getWidth();}public int height(){return bitmap.getHeight();}public int get(int x,int y){return bitmap.getPixel(x,y);}},anchors);
  java.util.List<Text.Line> lines=new java.util.ArrayList<>();
  int movesTop=-1,movesEnd=bitmap.getHeight();
  for(Text.TextBlock block:t.getTextBlocks())for(Text.Line line:block.getLines()){
   Rect b=line.getBoundingBox();if(b==null)continue;lines.add(line);
   String key=line.getText().replaceAll("[^A-Za-z]", "").toLowerCase(java.util.Locale.ROOT);
   if(key.contains("gymsraids")||key.contains("trainerbattles"))movesTop=Math.max(movesTop,b.bottom);
   if(key.equals("newattack"))movesEnd=Math.min(movesEnd,b.top);
  }
  lines.sort(java.util.Comparator.comparingInt(line->line.getBoundingBox().top));
  // A missed heading must not suppress every move. Restrict fallback to the
  // lower half of a recognized CP/HP details screen, above NEW ATTACK.
  if(movesTop<0&&!r.cp.equals("Unknown")&&r.maximum>0)movesTop=(int)(bitmap.getHeight()*.50);
  if(movesTop>=0)for(Text.Line line:lines){Rect b=line.getBoundingBox();if(b.top>movesTop&&b.bottom<=movesEnd){
   r.seeMove(line.getText(),moveCatalog);
   // ML Kit sometimes merges name, icon and damage into a single line.
   StringBuilder words=new StringBuilder();for(Text.Element element:line.getElements()){
    String word=element.getText();if(word.matches("[0-9]+"))continue;
    if(words.length()>0)words.append(" ");words.append(word);
   }r.seeMove(words.toString(),moveCatalog);
  }}
  String key=r.fingerprint();String observed=r.summary()+"|"+key;
  boolean relevant=!r.species.equals("Unknown")||!r.cp.equals("Unknown")||r.current>=0||r.iv!=null;
  if(relevant&&observed.equals(previousSummary))matches++;else matches=1;
  previousSummary=observed;stable=relevant&&matches>=2;
  if(key.isEmpty()||!key.equals(linkedKey)){linkedId="";linkedKey="";}
  String memory="";
  if(stable&&!key.isEmpty()){
   if(linkedId.isEmpty()){
    java.util.List<JSONObject> candidates=recordStore.matches(key);
    if(candidates.size()==1&&!RecordStore.conflict(r,candidates.get(0))){linkedId=candidates.get(0).optString("id");linkedKey=key;}
    else if(candidates.size()>1)memory="Multiple saved matches — tap Link record.";
   }
   if(!linkedId.isEmpty()){
    JSONObject record=recordStore.get(linkedId);
    if(record==null||RecordStore.conflict(r,record)){linkedId="";linkedKey="";memory="Stats differ — tap Link record to review.";}
    else{RecordStore.recall(r,record);boolean ok=recordStore.update(linkedId,r,false);memory=ok?"Linked: "+record.optString("name"):"Could not update saved record.";}
   }else if(memory.isEmpty())memory="Tap Link record to use an existing Pokémon.";
  }else if(stable)memory="Show species, CP, HP, weight and height to link.";
  currentReading=r;
  structured=r.summary()+"\n"+PvpGrade.brief(r);if(fromImage)structured+="\nSpecies: tentative image match";
  if(!memory.isEmpty())structured+="\n"+memory;
  if(!relevant){structured="No Pokémon details identified. Open its details or appraisal. Inventory and map recognition are not ready.";matches=0;currentReading=null;}

  message.setText((stable?"Repeated reading • review before saving":"Reading • wait for another scan")+"\n\n"+structured);
 }
 int dp(int x){return (int)(x*getResources().getDisplayMetrics().density);}
 void overlay(){
  panel=new LinearLayout(this);panel.setOrientation(1);panel.setPadding(dp(10),dp(6),dp(10),dp(6));panel.setBackground(background());panel.setElevation(dp(8));
  title=new TextView(this);title.setText("GO Coach • tap to shrink");title.setTextColor(Color.rgb(100,235,190));title.setTextSize(16);title.setPadding(0,dp(10),0,dp(10));panel.addView(title);
  message=new TextView(this);message.setText("Open Pokémon GO. Select only the game when Android offers app sharing.");message.setTextColor(Color.WHITE);message.setTextSize(13);ScrollView readingScroll=new ScrollView(this);readingScroll.addView(message);panel.addView(readingScroll,new LinearLayout.LayoutParams(-1,dp(220)));
  controls=new LinearLayout(this);controls.setOrientation(1);panel.addView(controls);
  LinearLayout row=new LinearLayout(this);controls.addView(row);
  Button pause=new Button(this);pause.setText("Pause");row.addView(pause,new LinearLayout.LayoutParams(0,dp(48),1));pause.setOnClickListener(v->{paused=!paused;generation++;matches=0;stable=false;previousSummary="";structured="";linkedId="";linkedKey="";currentReading=null;pause.setText(paused?"Resume":"Pause");latest="";message.setText(paused?"Paused • no frames analyzed":"Resuming • waiting for a fresh reading");});
  Button stop=new Button(this);stop.setText("Stop");row.addView(stop,new LinearLayout.LayoutParams(0,dp(48),1));stop.setOnClickListener(v->stopSelf());
  Button grade=new Button(this);grade.setText("PvP grade");controls.addView(grade);grade.setOnClickListener(v->{
   if(currentReading==null||!stable){Toast.makeText(this,"Hold the Pokémon details still for a reading",Toast.LENGTH_SHORT).show();return;}
   final boolean wasPaused=paused;paused=true;generation++;
   AlertDialog dialog=new AlertDialog.Builder(this).setTitle("PvP grade").setMessage(PvpGrade.report(currentReading)).setPositiveButton("Close",null).create();
   dialog.setOnDismissListener(d->{paused=wasPaused;});showOverlayDialog(dialog);
  });
  Button link=new Button(this);link.setText("Link saved Pokémon");controls.addView(link);link.setOnClickListener(v->linkRecord());
  Button save=new Button(this);save.setText("Save reading");controls.addView(save);save.setOnClickListener(v->saveScan());
  
  params=new WindowManager.LayoutParams(dp(248),WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);params.gravity=Gravity.TOP|Gravity.LEFT;params.x=dp(12);params.y=dp(100);wm.addView(panel,params);
  title.setContentDescription("GO Coach. Tap to expand or collapse; drag to move.");
  title.setOnTouchListener(new View.OnTouchListener(){float x,y;int px,py;boolean moved;
   public boolean onTouch(View v,MotionEvent e){
    if(e.getAction()==MotionEvent.ACTION_DOWN){x=e.getRawX();y=e.getRawY();px=params.x;py=params.y;moved=false;return true;}
    if(e.getAction()==MotionEvent.ACTION_MOVE){if(Math.abs(e.getRawX()-x)+Math.abs(e.getRawY()-y)>dp(8))moved=true;if(moved){params.x=px+(int)(e.getRawX()-x);params.y=py+(int)(e.getRawY()-y);clamp();wm.updateViewLayout(panel,params);}return true;}
    if(e.getAction()==MotionEvent.ACTION_UP){if(!moved)setSmall(!small);return true;}return true;
   }});
  setSmall(true);
 }
 android.graphics.drawable.GradientDrawable background(){android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setColor(Color.rgb(18,30,44));d.setCornerRadius(dp(24));d.setStroke(dp(1),Color.rgb(68,116,112));return d;}
 void clamp(){Rect bounds=wm.getCurrentWindowMetrics().getBounds();params.x=Math.max(0,Math.min(Math.max(0,bounds.width()-params.width),params.x));params.y=Math.max(dp(36),Math.min(Math.max(dp(36),bounds.height()-panel.getHeight()-dp(52)),params.y));}
 void setSmall(boolean value){small=value;((View)message.getParent()).setVisibility(small?View.GONE:View.VISIBLE);controls.setVisibility(small?View.GONE:View.VISIBLE);title.setText(small?"GO":"GO Coach • tap to shrink");title.setGravity(small?Gravity.CENTER:Gravity.LEFT);title.setPadding(0,0,0,0);title.setLayoutParams(new LinearLayout.LayoutParams(-1,dp(44)));panel.setPadding(dp(8),dp(6),dp(8),dp(6));params.width=dp(small?56:248);params.height=small?dp(56):WindowManager.LayoutParams.WRAP_CONTENT;clamp();wm.updateViewLayout(panel,params);panel.post(()->{if(!dead){clamp();wm.updateViewLayout(panel,params);}});

 }
 void showOverlayDialog(AlertDialog dialog){dialog.getWindow().setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY);dialog.show();}
 void linkRecord(){
  if(paused||!stable||currentReading==null||currentReading.fingerprint().isEmpty()){Toast.makeText(this,"Hold details still with CP, HP, weight and height visible",Toast.LENGTH_LONG).show();return;}
  final Reading selected=currentReading;final JSONArray records=recordStore.all();
  if(records.length()==0){Toast.makeText(this,"Save a reading and add a collection record first",Toast.LENGTH_LONG).show();return;}
  String[] names=new String[records.length()];for(int i=0;i<names.length;i++){JSONObject o=records.optJSONObject(i);names[i]=o==null?"Unavailable":o.optString("name")+" · record "+(i+1);}
  showOverlayDialog(new AlertDialog.Builder(this).setTitle("Which saved Pokémon is this?").setItems(names,(d,which)->{
   JSONObject chosen=records.optJSONObject(which);if(chosen==null)return;
   showOverlayDialog(new AlertDialog.Builder(this).setTitle("Update "+chosen.optString("name")+"?").setMessage(selected.summary()+"\n\nConfirm this is the same individual. Visible values will update this record; missing values will be kept.").setPositiveButton("Link and update",(dd,w)->{
    if(recordStore.update(chosen.optString("id"),selected,true)){linkedId=chosen.optString("id");linkedKey=selected.fingerprint();Toast.makeText(this,"Linked. Saved appraisal and moves will appear on the next reading.",Toast.LENGTH_LONG).show();}else Toast.makeText(this,"Could not link record",Toast.LENGTH_LONG).show();
   }).setNegativeButton("Cancel",null).create());
  }).setNegativeButton("Cancel",null).create());
 }
 void saveScan(){if(paused||!stable||latest.trim().isEmpty()){Toast.makeText(this,"Hold a Pokémon screen still for two readings first",Toast.LENGTH_SHORT).show();return;}try{android.content.SharedPreferences prefs=getSharedPreferences("data",0);JSONArray a=new JSONArray(prefs.getString("scans","[]"));JSONObject o=new JSONObject();o.put("text",structured+"\n\nRaw OCR (unverified):\n"+latest);if(currentReading!=null){o.put("details",RecordStore.encode(currentReading));o.put("fingerprint",currentReading.fingerprint());}o.put("time",System.currentTimeMillis());a.put(o);while(a.length()>200)a.remove(0);prefs.edit().putString("scans",a.toString()).apply();Toast.makeText(this,"Saved for review in GO Coach",Toast.LENGTH_SHORT).show();}catch(Exception e){Toast.makeText(this,"Could not save reading",Toast.LENGTH_SHORT).show();}}
 public void onDestroy(){dead=true;visionWorker.execute(()->{if(visualMatcher!=null)visualMatcher.close();});visionWorker.shutdown();if(display!=null)display.release();if(reader!=null)reader.close();if(projection!=null)projection.stop();if(wm!=null&&panel!=null){try{wm.removeView(panel);}catch(Exception ignored){}}if(recognizer!=null&&!busy)recognizer.close();stopForeground(STOP_FOREGROUND_REMOVE);super.onDestroy();}
}
