package com.david.gocoach;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.os.*;
import android.graphics.*;
import android.hardware.display.*;
import android.media.*;
import android.media.projection.*;
import android.view.*;
import android.widget.*;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.*;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import org.json.*;

public class CoachService extends Service {
 final Handler handler=new Handler(Looper.getMainLooper());
 MediaProjection projection; VirtualDisplay display; ImageReader reader; WindowManager wm;
 LinearLayout panel,controls; TextView title; TextView message; TextRecognizer recognizer;
 WindowManager.LayoutParams params; boolean paused=false,busy=false,dead=false,small=false; long last=0;String latest="", previousSummary="", structured=""; int matches=0; boolean stable=false; int generation=0;
 public IBinder onBind(Intent i){return null;}
 public int onStartCommand(Intent intent,int flags,int id){
  if(intent==null || "STOP".equals(intent.getAction())){stopSelf();return START_NOT_STICKY;}
  if(projection!=null)return START_NOT_STICKY;
  NotificationManager nm=getSystemService(NotificationManager.class);nm.createNotificationChannel(new NotificationChannel("reader","Screen reader",NotificationManager.IMPORTANCE_LOW));
  PendingIntent stop=PendingIntent.getService(this,0,new Intent(this,CoachService.class).setAction("STOP"),PendingIntent.FLAG_IMMUTABLE);
  Notification n=new Notification.Builder(this,"reader").setSmallIcon(android.R.drawable.ic_menu_view).setContentTitle("GO Coach is reading your shared screen").setContentText("Tap Stop when finished").setOngoing(true).addAction(new Notification.Action.Builder(null,"Stop",stop).build()).build();
  startForeground(1,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
  try{
   Intent consent=intent.getParcelableExtra("consent");if(consent==null){stopSelf();return START_NOT_STICKY;}
   projection=((MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE)).getMediaProjection(Activity.RESULT_OK,consent);
   projection.registerCallback(new MediaProjection.Callback(){public void onStop(){stopSelf();}public void onCapturedContentResize(int width,int height){resize(width,height);}},handler);
   recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
   wm=getSystemService(WindowManager.class);Rect bounds=wm.getMaximumWindowMetrics().getBounds();
   createReader(bounds.width(),bounds.height());
   display=projection.createVirtualDisplay("GO Coach",reader.getWidth(),reader.getHeight(),getResources().getDisplayMetrics().densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,handler);
   overlay();
  }catch(Exception e){Toast.makeText(this,"Reader could not start. Reopen GO Coach and approve sharing again.",Toast.LENGTH_LONG).show();stopSelf();}
  return START_NOT_STICKY;
 }
 void createReader(int w,int h){reader=ImageReader.newInstance(w,h,PixelFormat.RGBA_8888,2);reader.setOnImageAvailableListener(r->frame(r),handler);}
 void resize(int w,int h){if(dead||display==null||w<=0||h<=0||reader==null)return;if(reader.getWidth()==w&&reader.getHeight()==h)return;display.setSurface(null);reader.close();createReader(w,h);display.resize(w,h,getResources().getDisplayMetrics().densityDpi);display.setSurface(reader.getSurface());}
 void frame(ImageReader r){
  Image im=null;Bitmap bitmap=null;
  try{
   im=r.acquireLatestImage();if(im==null)return;
   long now=SystemClock.elapsedRealtime();if(dead||paused||busy||now-last<2000)return;
   last=now; Image.Plane p=im.getPlanes()[0];int w=im.getWidth(),h=im.getHeight();int padded=p.getRowStride()/p.getPixelStride();
   Bitmap full=Bitmap.createBitmap(padded,h,Bitmap.Config.ARGB_8888);full.copyPixelsFromBuffer(p.getBuffer());bitmap=Bitmap.createBitmap(full,0,0,w,h);if(bitmap!=full)full.recycle();
   if(w>1080){Bitmap reduced=Bitmap.createScaledBitmap(bitmap,1080,Math.max(1,h*1080/w),true);bitmap.recycle();bitmap=reduced;}
   busy=true;final Bitmap work=bitmap;bitmap=null;final int epoch=generation;
   recognizer.process(InputImage.fromBitmap(work,0)).addOnSuccessListener(t->{if(!dead&&!paused&&epoch==generation){accept(t,work);}}).addOnFailureListener(e->{if(!dead&&message!=null)message.setText("Reading failed. Hold the game screen still and try again.");}).addOnCompleteListener(t->{work.recycle();busy=false;if(dead&&recognizer!=null)recognizer.close();});
  }catch(Exception e){if(message!=null)message.setText("Unable to read this frame. Try restarting sharing.");}
  finally{if(im!=null)im.close();if(bitmap!=null)bitmap.recycle();}
 }
 void accept(Text t,Bitmap bitmap){
  latest=t.getText();Reading r=Reading.parse(latest);
  Reading.Anchor[] anchors=new Reading.Anchor[3];
  for(Text.TextBlock block:t.getTextBlocks())for(Text.Line line:block.getLines()){
   String label=line.getText().trim().toLowerCase(java.util.Locale.ROOT);Rect b=line.getBoundingBox();if(b==null)continue;
   int i=label.equals("attack")?0:label.equals("defense")?1:label.equals("hp")?2:-1;
   if(i>=0 && b.left<bitmap.getWidth()*.50 && b.top>bitmap.getHeight()*.45)anchors[i]=new Reading.Anchor(b.left,b.bottom);
  }
  r.iv=Reading.appraisal(new Reading.Pixels(){public int width(){return bitmap.getWidth();}public int height(){return bitmap.getHeight();}public int get(int x,int y){return bitmap.getPixel(x,y);}},anchors);
  structured=r.summary();
  boolean relevant=!r.species.equals("Unknown")||!r.cp.equals("Unknown")||r.current>=0||r.iv!=null;
  if(relevant&&structured.equals(previousSummary))matches++;else matches=1;
  previousSummary=structured;stable=relevant&&matches>=2;
  if(!relevant){structured="No Pokémon details identified.\nOpen Appraise and hold still.\nMap/raid recognition is not ready yet.";matches=0;}
  message.setText((stable?"Repeated reading • review before saving":"Reading • wait for another scan")+"\n\n"+structured);
 }
 int dp(int x){return (int)(x*getResources().getDisplayMetrics().density);}
 void overlay(){
  panel=new LinearLayout(this);panel.setOrientation(1);panel.setPadding(dp(10),dp(6),dp(10),dp(6));panel.setBackground(background());panel.setElevation(dp(8));
  title=new TextView(this);title.setText("GO Coach • tap to shrink");title.setTextColor(Color.rgb(100,235,190));title.setTextSize(16);title.setPadding(0,dp(10),0,dp(10));panel.addView(title);
  message=new TextView(this);message.setText("Open Pokémon GO. Select only the game when Android offers app sharing.");message.setTextColor(Color.WHITE);message.setTextSize(13);message.setMaxLines(14);panel.addView(message);
  controls=new LinearLayout(this);controls.setOrientation(1);panel.addView(controls);
  LinearLayout row=new LinearLayout(this);controls.addView(row);
  Button pause=new Button(this);pause.setText("Pause");row.addView(pause,new LinearLayout.LayoutParams(0,dp(48),1));pause.setOnClickListener(v->{paused=!paused;generation++;matches=0;stable=false;previousSummary="";structured="";pause.setText(paused?"Resume":"Pause");latest="";message.setText(paused?"Paused • no frames analyzed":"Resuming • waiting for a fresh reading");});
  Button stop=new Button(this);stop.setText("Stop");row.addView(stop,new LinearLayout.LayoutParams(0,dp(48),1));stop.setOnClickListener(v->stopSelf());
  Button save=new Button(this);save.setText("Save reading");controls.addView(save);save.setOnClickListener(v->saveScan());
  
  params=new WindowManager.LayoutParams(dp(248),WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);params.gravity=Gravity.TOP|Gravity.LEFT;params.x=dp(12);params.y=dp(100);wm.addView(panel,params);
  title.setContentDescription("GO Coach. Tap to expand or collapse; drag to move.");
  title.setOnTouchListener(new View.OnTouchListener(){float x,y;int px,py;boolean moved;
   public boolean onTouch(View v,MotionEvent e){
    if(e.getAction()==MotionEvent.ACTION_DOWN){x=e.getRawX();y=e.getRawY();px=params.x;py=params.y;moved=false;return true;}
    if(e.getAction()==MotionEvent.ACTION_MOVE){if(Math.abs(e.getRawX()-x)+Math.abs(e.getRawY()-y)>dp(8))moved=true;if(moved){params.x=px+(int)(e.getRawX()-x);params.y=py+(int)(e.getRawY()-y);clamp();wm.updateViewLayout(panel,params);}return true;}
    if(e.getAction()==MotionEvent.ACTION_UP){if(!moved)setSmall(!small);return true;}return true;
   }});
  setSmall(true);
 }
 android.graphics.drawable.GradientDrawable background(){android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setColor(Color.rgb(18,30,44));d.setCornerRadius(dp(24));d.setStroke(dp(1),Color.rgb(68,116,112));return d;}
 void clamp(){Rect bounds=wm.getCurrentWindowMetrics().getBounds();params.x=Math.max(0,Math.min(Math.max(0,bounds.width()-params.width),params.x));params.y=Math.max(dp(36),Math.min(Math.max(dp(36),bounds.height()-panel.getHeight()-dp(52)),params.y));}
 void setSmall(boolean value){small=value;message.setVisibility(small?View.GONE:View.VISIBLE);controls.setVisibility(small?View.GONE:View.VISIBLE);title.setText(small?"GO":"GO Coach • tap to shrink");title.setGravity(small?Gravity.CENTER:Gravity.LEFT);title.setPadding(0,0,0,0);title.setLayoutParams(new LinearLayout.LayoutParams(-1,dp(44)));panel.setPadding(dp(8),dp(6),dp(8),dp(6));params.width=dp(small?56:248);params.height=small?dp(56):WindowManager.LayoutParams.WRAP_CONTENT;clamp();wm.updateViewLayout(panel,params);panel.post(()->{if(!dead){clamp();wm.updateViewLayout(panel,params);}});

 }
 void saveScan(){if(paused||!stable||latest.trim().isEmpty()){Toast.makeText(this,"Hold a Pokémon screen still for two readings first",Toast.LENGTH_SHORT).show();return;}try{android.content.SharedPreferences prefs=getSharedPreferences("data",0);JSONArray a=new JSONArray(prefs.getString("scans","[]"));JSONObject o=new JSONObject();o.put("text",structured+"\n\nRaw OCR (unverified):\n"+latest);o.put("time",System.currentTimeMillis());a.put(o);while(a.length()>200)a.remove(0);prefs.edit().putString("scans",a.toString()).apply();Toast.makeText(this,"Saved for review in GO Coach",Toast.LENGTH_SHORT).show();}catch(Exception e){Toast.makeText(this,"Could not save reading",Toast.LENGTH_SHORT).show();}}
 public void onDestroy(){dead=true;if(display!=null)display.release();if(reader!=null)reader.close();if(projection!=null)projection.stop();if(wm!=null&&panel!=null){try{wm.removeView(panel);}catch(Exception ignored){}}if(recognizer!=null&&!busy)recognizer.close();stopForeground(STOP_FOREGROUND_REMOVE);super.onDestroy();}
}
