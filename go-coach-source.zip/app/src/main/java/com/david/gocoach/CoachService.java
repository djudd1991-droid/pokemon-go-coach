package com.david.gocoach;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.os.*;
import android.graphics.*;
import android.hardware.display.*;
import android.media.*;
import android.media.projection.*;
import android.view.*;
import android.widget.*;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.*;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import org.json.*;

public class CoachService extends Service {
 final Handler handler=new Handler(Looper.getMainLooper());
 MediaProjection projection; VirtualDisplay display; ImageReader reader; WindowManager wm;
 LinearLayout panel,controls; TextView message; TextRecognizer recognizer;
 WindowManager.LayoutParams params; boolean paused=false,busy=false,dead=false,small=false; long last=0;String latest="";
 public IBinder onBind(Intent i){return null;}
 public int onStartCommand(Intent intent,int flags,int id){
  if(intent==null || "STOP".equals(intent.getAction())){stopSelf();return START_NOT_STICKY;}
  if(projection!=null)return START_NOT_STICKY;
  NotificationManager nm=getSystemService(NotificationManager.class);nm.createNotificationChannel(new NotificationChannel("reader","Screen reader",NotificationManager.IMPORTANCE_LOW));
  PendingIntent stop=PendingIntent.getService(this,0,new Intent(this,CoachService.class).setAction("STOP"),PendingIntent.FLAG_IMMUTABLE);
  Notification n=new Notification.Builder(this,"reader").setSmallIcon(android.R.drawable.ic_menu_view).setContentTitle("GO Coach is reading your shared screen").setContentText("Tap Stop when finished").setOngoing(true).addAction(new Notification.Action.Builder(null,"Stop",stop).build()).build();
  startForeground(1,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
  try{
   Intent consent=intent.getParcelableExtra("consent");if(consent==null){stopSelf();return START_NOT_STICKY;}
   projection=((MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE)).getMediaProjection(Activity.RESULT_OK,consent);
   projection.registerCallback(new MediaProjection.Callback(){public void onStop(){stopSelf();}public void onCapturedContentResize(int width,int height){resize(width,height);}},handler);
   recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
   wm=getSystemService(WindowManager.class);Rect bounds=wm.getMaximumWindowMetrics().getBounds();
   createReader(bounds.width(),bounds.height());
   display=projection.createVirtualDisplay("GO Coach",reader.getWidth(),reader.getHeight(),getResources().getDisplayMetrics().densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,handler);
   overlay();
  }catch(Exception e){Toast.makeText(this,"Reader could not start. Reopen GO Coach and approve sharing again.",Toast.LENGTH_LONG).show();stopSelf();}
  return START_NOT_STICKY;
 }
 void createReader(int w,int h){reader=ImageReader.newInstance(w,h,PixelFormat.RGBA_8888,2);reader.setOnImageAvailableListener(r->frame(r),handler);}
 void resize(int w,int h){if(dead||display==null||w<=0||h<=0||reader==null)return;if(reader.getWidth()==w&&reader.getHeight()==h)return;display.setSurface(null);reader.close();createReader(w,h);display.resize(w,h,getResources().getDisplayMetrics().densityDpi);display.setSurface(reader.getSurface());}
 void frame(ImageReader r){
  Image im=null;Bitmap bitmap=null;
  try{
   im=r.acquireLatestImage();if(im==null)return;
   long now=SystemClock.elapsedRealtime();if(dead||paused||busy||now-last<3000)return;
   last=now; Image.Plane p=im.getPlanes()[0];int w=im.getWidth(),h=im.getHeight();int padded=p.getRowStride()/p.getPixelStride();
   Bitmap full=Bitmap.createBitmap(padded,h,Bitmap.Config.ARGB_8888);full.copyPixelsFromBuffer(p.getBuffer());bitmap=Bitmap.createBitmap(full,0,0,w,h);if(bitmap!=full)full.recycle();
   if(w>1080){Bitmap reduced=Bitmap.createScaledBitmap(bitmap,1080,Math.max(1,h*1080/w),true);bitmap.recycle();bitmap=reduced;}
   busy=true;final Bitmap work=bitmap;bitmap=null;
   recognizer.process(InputImage.fromBitmap(work,0)).addOnSuccessListener(t->{if(!dead&&!paused){latest=t.getText();if(message!=null)message.setText(advice(latest));}}).addOnFailureListener(e->{if(!dead&&message!=null)message.setText("Reading failed. Hold the game screen still and try again.");}).addOnCompleteListener(t->{work.recycle();busy=false;if(dead&&recognizer!=null)recognizer.close();});
  }catch(Exception e){if(message!=null)message.setText("Unable to read this frame. Try restarting sharing.");}
  finally{if(im!=null)im.close();if(bitmap!=null)bitmap.recycle();}
 }
 String advice(String raw){
  if(raw.trim().isEmpty())return "No readable text yet. Open a Pokémon’s details or your Item Bag.";
  String s=raw.toLowerCase(java.util.Locale.ROOT);String label="Text detected • unverified";String tip="Hold the screen still. Save a reading to review in GO Coach.";
  if(s.contains("attack")&&s.contains("defense")){label="Possible appraisal";tip="Appraisal bars and collectible status need your confirmation in this test.";}
  else if(s.contains("raid")||s.contains("battle party")){label="Possible raid screen";tip="Boss recognition and team selection are coming later. No team recommendation yet.";}
  else if(s.contains("stardust")&&s.contains("candy")){label="Possible Pokémon details";tip="Open Appraise to show its stats. Do not transfer based on this reading.";}
  else if(s.contains("potion")||s.contains("revive")){label="Possible Item Bag";tip="Item quantities are not verified yet. Fainted Pokémon need Revives; injured Pokémon use Potions.";}
  return label+"\n"+tip+"\n\nRead: "+raw.substring(0,Math.min(160,raw.length()));
 }
 int dp(int x){return (int)(x*getResources().getDisplayMetrics().density);}
 void overlay(){
  panel=new LinearLayout(this);panel.setOrientation(1);panel.setPadding(dp(10),dp(6),dp(10),dp(6));panel.setBackgroundColor(Color.rgb(25,35,50));
  TextView title=new TextView(this);title.setText("GO Coach • drag here");title.setTextColor(Color.rgb(100,235,190));title.setTextSize(16);title.setPadding(0,dp(10),0,dp(10));panel.addView(title);
  message=new TextView(this);message.setText("Open Pokémon GO. Select only the game when Android offers app sharing.");message.setTextColor(Color.WHITE);message.setTextSize(13);message.setMaxLines(10);panel.addView(message);
  controls=new LinearLayout(this);controls.setOrientation(1);panel.addView(controls);
  LinearLayout row=new LinearLayout(this);controls.addView(row);
  Button pause=new Button(this);pause.setText("Pause");row.addView(pause,new LinearLayout.LayoutParams(0,dp(48),1));pause.setOnClickListener(v->{paused=!paused;pause.setText(paused?"Resume":"Pause");latest="";message.setText(paused?"Paused • no frames analyzed":"Resuming • waiting for a fresh reading");});
  Button stop=new Button(this);stop.setText("Stop");row.addView(stop,new LinearLayout.LayoutParams(0,dp(48),1));stop.setOnClickListener(v->stopSelf());
  Button save=new Button(this);save.setText("Save reading");controls.addView(save);save.setOnClickListener(v->saveScan());
  Button mini=new Button(this);mini.setText("Minimize / expand");panel.addView(mini);mini.setOnClickListener(v->{small=!small;message.setVisibility(small?View.GONE:View.VISIBLE);controls.setVisibility(small?View.GONE:View.VISIBLE);});
  params=new WindowManager.LayoutParams(dp(270),WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);params.gravity=Gravity.TOP|Gravity.LEFT;params.x=dp(12);params.y=dp(100);wm.addView(panel,params);
  title.setOnTouchListener(new View.OnTouchListener(){float x,y;int px,py;public boolean onTouch(View v,android.view.MotionEvent e){if(e.getAction()==MotionEvent.ACTION_DOWN){x=e.getRawX();y=e.getRawY();px=params.x;py=params.y;return true;}if(e.getAction()==MotionEvent.ACTION_MOVE){Rect bounds=wm.getCurrentWindowMetrics().getBounds();params.x=Math.max(0,Math.min(bounds.width()-panel.getWidth(),px+(int)(e.getRawX()-x)));params.y=Math.max(dp(32),Math.min(bounds.height()-panel.getHeight()-dp(48),py+(int)(e.getRawY()-y)));wm.updateViewLayout(panel,params);return true;}return true;}});
 }
 void saveScan(){if(paused||latest.trim().isEmpty()){Toast.makeText(this,"Wait for a fresh reading first",Toast.LENGTH_SHORT).show();return;}try{android.content.SharedPreferences prefs=getSharedPreferences("data",0);JSONArray a=new JSONArray(prefs.getString("scans","[]"));JSONObject o=new JSONObject();o.put("text",latest);o.put("time",System.currentTimeMillis());a.put(o);while(a.length()>200)a.remove(0);prefs.edit().putString("scans",a.toString()).apply();Toast.makeText(this,"Saved for review in GO Coach",Toast.LENGTH_SHORT).show();}catch(Exception e){Toast.makeText(this,"Could not save reading",Toast.LENGTH_SHORT).show();}}
 public void onDestroy(){dead=true;if(display!=null)display.release();if(reader!=null)reader.close();if(projection!=null)projection.stop();if(wm!=null&&panel!=null){try{wm.removeView(panel);}catch(Exception ignored){}}if(recognizer!=null&&!busy)recognizer.close();stopForeground(STOP_FOREGROUND_REMOVE);super.onDestroy();}
}
