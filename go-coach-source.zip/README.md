# GO Coach 0.2 — appraisal prototype

Native Android / Java, Android 11+, target Android 15. Intended first test device: Moto G (2025).
Free local rule-based prototype. No OpenAI API key, paid AI, automatic taps, or Pokémon GO login.

Implemented: Android screen-sharing foreground service; notification Stop; draggable/minimizable overlay; Pause/Resume/Stop; bundled ML Kit Latin text recognition throttled to once per two seconds; structured species/CP/HP readings; experimental anchored appraisal-bar recognition; two matching summaries required before saving; save unverified text readings (last 200); separate user-confirmed collection records with UUIDs; protected-by-default records; confirmed local record removal; navigation-bar insets; projection stop cleanup.

Not implemented: general species/form recognition outside English appraisal sentences, visual shiny/background recognition, automatic duplicate matching, automatic collection or transfer reconciliation, inventory quantity parsing, healing prioritization, raid counters, PvP rankings, research tracking, event synchronization, unrestricted conversational AI. The prototype labels these limits in the app. Do not make transfer or spending decisions based on OCR.

Collection and text scans are stored in app-private preferences; screenshots are processed in memory, not saved. Uninstalling deletes records; export/backup is not yet implemented. ML Kit dependencies may include their own service components; this app contains no custom screen-upload code. Select Pokémon GO only in Android's sharing picker to avoid reading other apps or the overlay itself.

Development signing key is bundled solely so subsequent test APKs can update the same install. It is not a production signing credential. Preserve it for future test builds, keep this project private, and replace the signing approach before distribution.

Validation performed: Java compiler syntax parsing; standalone Reading class compilation; species/CP/HP parsing and invalid-data checks; appraisal returned 13/15/11 on both provided Cinderace screenshots with manually supplied label coordinates; missing-label and blank-screen rejection; manifest XML parsing and archive integrity. Live ML Kit label detection is not covered by those screenshot tests. Actual Android compilation, OCR accuracy, display-resize handling, battery/memory use, and device behavior require GitHub/device testing. Version 0.1 was built successfully in the user’s GitHub repository and ran on the phone. Version 0.2 still requires a GitHub build and device testing.

## Phone test checklist
1. Install APK; open app. Confirm all controls clear system navigation.
2. Allow overlay; start reader; choose Pokémon GO only in sharing picker.
3. Open details and bag; confirm recognized text changes within several seconds.
4. Drag and minimize bubble; verify no blocked controls.
5. Pause: readings stop; resume: fresh reading appears. Save a text reading.
6. Stop via bubble, then restart. Stop via notification. Lock phone; sharing should end.
7. Open saved scans; add two separate Pokémon records; restart app and verify persistence.
8. Delete one saved record with confirmation; verify other record remains.
9. Report exact errors or a screenshot of this prototype to continue development.

## Design backlog
Preserve all requested goals: live user-controlled guidance; owned Pokémon/appraisals; duplicate records; collectible protection (shiny/special/location backgrounds); confirmed transfer tracking; owned item/resource checks with stale/unknown handling; fainted/injured detection; raid boss and encounter identification; current official events; purpose-specific coaching. Prioritize trustworthy recognition before recommendations.

References:
https://developer.android.com/media/grow/media-projection
https://developers.google.com/ml-kit/vision/text-recognition/v2/android
https://developer.android.com/build/releases/agp-8-9-0-release-notes

## Version 0.2 update
Upload this ZIP as go-coach-source.zip at the repository root, replacing the old source ZIP. The existing workflow builds it automatically. The artifact may still be labeled v0.1 because that label is in the unchanged workflow; the installed app is version 0.2. Install over the existing app to keep records.

The overlay starts as a 56dp GO button. Tap to expand/collapse; drag to reposition. Pause and Stop appear when expanded. Notification Stop remains available. Two matching readings reduce flicker but do not prove accuracy: confirm each field. Bar measurement requires Attack, Defense and HP labels and matching track geometry. It intentionally returns unknown when checks fail. No nickname-to-species inference, no automatic transfer recommendations, no automatic collection writes.
