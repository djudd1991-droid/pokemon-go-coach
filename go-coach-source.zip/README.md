# GO Coach 0.4 — remembered appraisals and visible moves

## Update and test
Replace go-coach-source.zip in the GitHub repository root. Keep the workflow unchanged. Install the new APK over the existing app; do not uninstall. The home screen must say 0.4. Existing signing key, application ID, saved scans, and collection remain in use.

1. Start reader and share Pokémon GO only.
2. Open Cinderace's ordinary details screen. Keep CP, current/max HP, weight, height, and moves visible; move the coach below its model. Wait for two stable readings.
3. Tap GO > Link saved Pokémon > choose the existing Cinderace record > Link and update. This one-time link is needed for older records lacking structured identifying fields.
4. Its stored appraisal should appear with “saved”. Show the GYMS & RAIDS / TRAINER BATTLES section and visible move names. Fast/charged slots should fill after two readings and update the linked record.
5. Open Appraise, then return to details: the linked record preserves IVs and moves. Restarting the reader should recall a unique matching record once the identifying fields are read again.
6. Switch Pokémon: mismatching/incomplete identifying fields clear the active link. Never confirm a link unless it is the same individual.

## Exact behavior
Persistent record matching uses species, CP, max HP, weight and height. It requires all five; it never joins by CP alone. This is a conservative screen-derived signature, NOT a game-provided unique Pokémon ID. Identical unscanned Pokémon remain a limitation. Two saved matches require manual selection; contradictory visible IVs block automatic updates. Power-ups/evolution or unreadable fields may require a fresh explicit link. Scrolling those fields offscreen disables linking until they are visible again.

Legacy appraisal text is migrated only when a user explicitly links a record. Existing IDs and protection/trait fields are preserved. A prior structured snapshot is retained on a data change. Appraisal and moves are merged without replacing missing readings with unknown. Previously saved IVs and moves are labeled. Current HP is read live, not copied from saved health.

Moves use a packaged catalog derived from PokeMiners Game Master moveSettings, fetched during this update. Source: https://github.com/PokeMiners/game_masters/blob/master/latest/latest.json . Named *_FAST entries are classified fast; other named move entries charged. Numeric/unnamed entries are excluded. Exact normalized OCR names are accepted only below the visible battle-section heading and above NEW ATTACK. OCR damage numbers are ignored. A missed or offscreen row is not evidence that a move was removed. An unseen second charged move is retained and labeled saved; it may be stale after a TM until rescanned. This is an English-layout prototype and does not infer hidden moves or advise TMs.

Live auto-updates apply only to the matched existing record; creating new Pokémon still requires scan review. If free-form stats are edited while creating a record, the unedited structured scan is not silently attached to the edited record. Old scan records remain readable.

## Validation
Java syntax parsing passed. The actual Reading and RecordStore classes were compiled against a small preferences test adapter and JSON library. Checks passed for legacy-IV migration, persistence after reopening, fast/charged name parsing and noise rejection, same-CP/different-weight identity separation, missing-field rejection, duplicate ambiguity, conflicting-IV non-overwrite, protection preservation, and retaining an offscreen second charged move.

Android compilation is delegated to the existing GitHub workflow. v0.4 has not yet been built or run on the phone in this session. Live OCR bounding boxes, matching consistency, and overlay usability need device testing. Visual recognition remains the limited v0.3 experiment; no expansion of wild-map, raid, shiny, background, or item coverage in this update.

Test adapter files: research/memory-check. They require org.json:json:20240303 and are not included in the APK source set. No user APK key changes.

---

Previous visual-prototype implementation and evidence:

# GO Coach 0.3 — experimental visual matching

## Phone update
Upload go-coach-source.zip to the existing repository root, replacing the prior ZIP. Keep .github/workflows/build.yml unchanged. After the newest build succeeds, download its APK and install over version 0.2. The GitHub artifact may still be named v0.1: the installed app must display GO Coach 0.3. Do not uninstall, because that deletes saved records. Existing test signing key and application ID are preserved.

## What changed
Added offline OpenCV SIFT reference matching for a single Pokémon on the details screen, with seven reference descriptors for Cinderace, normal/shiny Metagross, normal/Mystic-accessory Lapras, Mewtwo and Armored Mewtwo. The source data is from PokeMiners; see research/reference-manifest.json. Visual matching operates on the upper model area, excluding CP and name labels. OCR is used to determine whether a details screen is open, not to identify the species visually.

Tentative visual species is used only when the appraisal sentence has not already identified the species. A visual match does not verify shiny, costume, background, IVs or individual collection identity. Normal and alternate references are grouped by species, except Armored Mewtwo which is a distinct target. Existing appraisal parsing, scan review, protected manual collection records, capture consent, movable 56dp bubble, Pause/Stop and notification Stop are preserved. Frames stay in memory.

Visual processing uses a single worker thread and one OpenCV thread; capture processing is throttled to one cycle per three seconds and skips frames while busy. Native performance, memory use and compatibility still need device testing. The APK will be larger because OpenCV includes native libraries.

## Evidence and limitations
A Python/OpenCV baseline with independent icon references identified four supplied details screenshots: Cinderace, shiny Metagross, decorated Lapras and regular Mewtwo. Armored Mewtwo remained unknown at the fixed acceptance threshold. An unseen Glimmet screenshot, unrelated map crop and item-bag crop were rejected. This tiny selected set is not a general accuracy measurement.

A separate exploratory Glimmet test used foreground-extracted reference frames at seconds 1, 3 and 4, then checked frames 6, 8 and 10 from the SAME recording. None passed. These correlated frames would not establish generalization even if successful. Glimmet references are therefore excluded from the app.

App reference vectors were validated and predictions with species grouping checked. Java syntax parsing passed. Existing standalone species/health/appraisal tests passed. A full Android build has NOT been performed locally; GitHub must compile version 0.3, and live recognition must be tested. Version 0.2 was previously built and tested successfully by the user.

This is visual feature matching, not a trained neural detector. Wild-map multi-object identification, general raid recognition, Glimmet, reliable armor detection, broad species/form coverage and visual collectible verification are NOT ready. Unknown results are expected when poses/angles change or features are insufficient. No transfer recommendation is based on this experiment. No paid API is used.

## First device test
1. Confirm header says version 0.3.
2. Start screen sharing for Pokémon GO only.
3. Open Cinderace's ordinary details screen, with Appraise CLOSED.
4. Keep the GO bubble below the model; wait 6–10 seconds, then expand it.
5. Check for Cinderace and Species: tentative image match.
6. Test regular Mewtwo, Metagross and Lapras the same way.
7. Show an unrelated Pokémon: an unknown result is preferable to a wrong name.
8. Report lag, crashes, wrong matches or unknown results. Keep Appraise available as a text-based fallback.

## Reproduce desktop baseline
Inside research, run: python -m pip install opencv-python-headless numpy
Then: python evaluate.py
Test inputs are cropped screen regions with no species names or CP. Evaluation covers the supplied views only and does not benchmark Android latency. The output JSON includes match counts, RANSAC inliers and spatial coverage. Fixed gates: at least 10 inliers, 1.5% target area coverage, and 4 more inliers than runner-up. Android compares runners-up by species.

Sources:
https://github.com/PokeMiners/pogo_assets
https://docs.opencv.org/4.10.0/d5/df8/tutorial_dev_with_OCV_on_Android.html
https://docs.opencv.org/3.4.18/d1/de0/tutorial_py_feature_homography.html

Assets retain their owners' rights; the PokeMiners repository describes them as educational-use material. This is a private research prototype, not a production redistribution license. The bundled signing key is for development only.

## Version 0.5 — move reader and PvP grades

- Move parser tolerates up to two leading OCR icon letters and damage digits;
  missing section headings use a bounded details-screen fallback.
- Saved IVs/moves and signing key retained. Open the moves section for live
  move updates; linked records retain values when those fields leave the screen.
- PvP grade is available in the floating coach and each structured collection
  record. The live panel shows CP eligibility automatically.
- IV rank: all 4096 spreads, IV floor 0, levels 1–50 in half levels, highest
  legal CP level, attack × defense × floored HP, competition ranks for ties.
  No Best Buddy boost, evolution projections, or cup-specific eligibility.
- Species rankings and recommended moves: bundled PvPoke open-league overall
  snapshot downloaded 2026-09-08. These are not live rankings or a simulation
  of the scanned moves/team. Elite/event moves are marked; bag ownership is
  not checked. Species recognition remains tentative and supports only the
  existing reference set; grading data coverage does not expand recognition.
- Over-limit Pokémon do not get misleading capped-league investment grades.
- Validation: Java parser/memory tests, rank/CP-boundary/missing-data checks,
  Java syntax parsing. No Android SDK is available locally; GitHub Actions
  builds the APK, and live ML Kit behavior still requires phone verification.

Data and CPM source: https://github.com/pvpoke/pvpoke (MIT; license bundled in
research/PVPOKE-LICENSE.txt). Ranking source paths:
`src/data/rankings/all/overall/rankings-{1500,2500,10000}.json`;
base stats and moves: `src/data/gamemaster.json`; multipliers:
`src/js/pokemon/Pokemon.js`. No PvPoke code executes remotely at runtime.

## Version 0.6 — collection redesign

White collection list and blue navigation bar, native IV percentage rings,
reference portraits, CP/HP and saved IV values, type-colored move badges.
Search species/nickname/moves; sort by time, IV, CP or name; filter protected
records. Tap for full appraisal details, league grade access and a working
transfer-protection setting. Removal confirms and targets stable record ID.
Insets keep navigation clear of Android system controls. Unknown data remains
unknown. Bundled reference artwork is not a scan of the individual and does
not establish shiny/costume/background status. No invented letter grades,
levels or unsupported simulator switches. Existing records/signing preserved.
