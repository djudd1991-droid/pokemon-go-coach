# GO Coach 0.3 — experimental visual matching

## Phone update
Upload go-coach-source.zip to the existing repository root, replacing the prior ZIP. Keep .github/workflows/build.yml unchanged. After the newest build succeeds, download its APK and install over version 0.2. The GitHub artifact may still be named v0.1: the installed app must display GO Coach 0.3. Do not uninstall, because that deletes saved records. Existing test signing key and application ID are preserved.

## What changed
Added offline OpenCV SIFT reference matching for a single Pokémon on the details screen, with seven reference descriptors for Cinderace, normal/shiny Metagross, normal/Mystic-accessory Lapras, Mewtwo and Armored Mewtwo. The source data is from PokeMiners; see research/reference-manifest.json. Visual matching operates on the upper model area, excluding CP and name labels. OCR is used to determine whether a details screen is open, not to identify the species visually.

Tentative visual species is used only when the appraisal sentence has not already identified the species. A visual match does not verify shiny, costume, background, IVs or individual collection identity. Normal and alternate references are grouped by species, except Armored Mewtwo which is a distinct target. Existing appraisal parsing, scan review, protected manual collection records, capture consent, movable 56dp bubble, Pause/Stop and notification Stop are preserved. Frames stay in memory.

Visual processing uses a single worker thread and one OpenCV thread; capture processing is throttled to one cycle per three seconds and skips frames while busy. Native performance, memory use and compatibility still need device testing. The APK will be larger because OpenCV includes native libraries.

## Evidence and limitations
A Python/OpenCV baseline with independent icon references identified four supplied details screenshots: Cinderace, shiny Metagross, decorated Lapras and regular Mewtwo. Armored Mewtwo remained unknown at the fixed acceptance threshold. An unseen Glimmet screenshot, unrelated map crop and item-bag crop were rejected. This tiny selected set is not a general accuracy measurement.

A separate exploratory Glimmet test used foreground-extracted reference frames at seconds 1, 3 and 4, then checked frames 6, 8 and 10 from the SAME recording. None passed. These correlated frames would not establish generalization even if successful. Glimmet references are therefore excluded from the app.

App reference vectors were validated and predictions with species grouping checked. Java syntax parsing passed. Existing standalone species/health/appraisal tests passed. A full Android build has NOT been performed locally; GitHub must compile version 0.3, and live recognition must be tested. Version 0.2 was previously built and tested successfully by the user.

This is visual feature matching, not a trained neural detector. Wild-map multi-object identification, general raid recognition, Glimmet, reliable armor detection, broad species/form coverage and visual collectible verification are NOT ready. Unknown results are expected when poses/angles change or features are insufficient. No transfer recommendation is based on this experiment. No paid API is used.

## First device test
1. Confirm header says version 0.3.
2. Start screen sharing for Pokémon GO only.
3. Open Cinderace's ordinary details screen, with Appraise CLOSED.
4. Keep the GO bubble below the model; wait 6–10 seconds, then expand it.
5. Check for Cinderace and Species: tentative image match.
6. Test regular Mewtwo, Metagross and Lapras the same way.
7. Show an unrelated Pokémon: an unknown result is preferable to a wrong name.
8. Report lag, crashes, wrong matches or unknown results. Keep Appraise available as a text-based fallback.

## Reproduce desktop baseline
Inside research, run: python -m pip install opencv-python-headless numpy
Then: python evaluate.py
Test inputs are cropped screen regions with no species names or CP. Evaluation covers the supplied views only and does not benchmark Android latency. The output JSON includes match counts, RANSAC inliers and spatial coverage. Fixed gates: at least 10 inliers, 1.5% target area coverage, and 4 more inliers than runner-up. Android compares runners-up by species.

Sources:
https://github.com/PokeMiners/pogo_assets
https://docs.opencv.org/4.10.0/d5/df8/tutorial_dev_with_OCV_on_Android.html
https://docs.opencv.org/3.4.18/d1/de0/tutorial_py_feature_homography.html

Assets retain their owners' rights; the PokeMiners repository describes them as educational-use material. This is a private research prototype, not a production redistribution license. The bundled signing key is for development only.
